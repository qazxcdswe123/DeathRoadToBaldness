#include <string>
using namespace std;

bool checkUserInput(string input);
double calculate(string rpn);
void PrintDigit(int number);
string changeToRPN(string original);
void print_like_LCD(double num);