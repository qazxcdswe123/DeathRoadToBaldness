#include <iostream>
#include "15_headf.h"
using namespace std;

int main()
{
    calculation1();
    calculation2();
}