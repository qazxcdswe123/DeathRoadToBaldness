int factorial(int n);
double calculation1();
int calculation2();