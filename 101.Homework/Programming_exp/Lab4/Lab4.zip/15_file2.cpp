#include <iostream>
#include "15_headf.h"
using namespace std;

double calculation1()
{
    double y = (factorial(5) + factorial(7)) / factorial(8);
    return y;
}